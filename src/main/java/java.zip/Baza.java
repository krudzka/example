import java.util.ArrayList;

/**
 * Created by RENT on 2017-02-11.
 */
public class Baza {
    ArrayList<Film> baza = new ArrayList<>();
    String nazwaFilmu;


    void wypisz(ArrayList<Film> baza) {
        for (int i = 0; i < baza.size(); i++) {
            System.out.println(baza);
        }


    }

    void dodaj(Film Nazwa) {
        baza.add(Nazwa);

        System.out.println(baza);
    }

    void usuń(Film Nazwa) {
        baza.remove(Nazwa);
        System.out.println(baza);
    }


    public static void main(String[] args) {
        Baza baza = new Baza();
        Film film = new Film("Titanic", 5);
       // Film film1 = new Film("Harry Potter", 4);
        film.wypisz();
       // baza.dodaj(film1);
        baza.wypisz();

    }
}




