/**
 * Created by RENT on 2017-02-11.
 */

public class Film {
    String nazwaFilmu;
    int ocena;

    Film(String nazwaFilmu, int ocena) {
        this.nazwaFilmu=nazwaFilmu;
        this.ocena=ocena;

    }
    void wypisz (){
        System.out.println(nazwaFilmu + " " + ocena);
    }


}

